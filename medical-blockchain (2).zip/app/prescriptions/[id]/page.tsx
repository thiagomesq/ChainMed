"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, Download, FileText, Package2, Share2 } from "lucide-react"
import { getPrescriptionDetails, verifyPrescriptionZK } from "@/lib/blockchain"

// Tipo para detalhes da prescrição
interface PrescriptionDetails {
  id: string
  doctorName: string
  doctorCrm: string
  patientName: string
  patientCpf: string
  date: string
  medication: string
  dosage: string
  instructions: string
  transactionHash: string
  verified: boolean
}

export default function PrescriptionDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const [prescription, setPrescription] = useState<PrescriptionDetails | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isVerifying, setIsVerifying] = useState(false)
  const [verificationStatus, setVerificationStatus] = useState<"none" | "verifying" | "verified" | "failed">("none")

  // Carregar detalhes da prescrição
  useEffect(() => {
    const loadPrescriptionDetails = async () => {
      if (!params.id) return

      try {
        const data = await getPrescriptionDetails(params.id as string)
        setPrescription(data)
      } catch (error) {
        console.error("Failed to load prescription details:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadPrescriptionDetails()
  }, [params.id])

  // Verificar a prescrição usando ZK proofs
  const handleVerifyPrescription = async () => {
    if (!prescription) return

    setIsVerifying(true)
    setVerificationStatus("verifying")

    try {
      const isVerified = await verifyPrescriptionZK(prescription.id)
      setVerificationStatus(isVerified ? "verified" : "failed")
    } catch (error) {
      console.error("Verification failed:", error)
      setVerificationStatus("failed")
    } finally {
      setIsVerifying(false)
    }
  }

  // Função para baixar a prescrição como PDF (simulada)
  const handleDownloadPrescription = () => {
    alert("Funcionalidade de download será implementada em uma versão futura.")
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando detalhes da prescrição...</p>
      </div>
    )
  }

  if (!prescription) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <p className="text-lg mb-4">Prescrição não encontrada</p>
        <Button onClick={() => router.back()}>Voltar</Button>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-3 flex items-center">
          <Link href="/" className="flex items-center space-x-2">
            <Package2 className="h-6 w-6 text-emerald-500" />
            <h1 className="text-xl font-bold text-gray-900">MedChain</h1>
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Button variant="ghost" className="mb-6 flex items-center" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>

          <Card className="mb-6">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-2xl flex items-center">
                  <FileText className="h-6 w-6 mr-2 text-emerald-500" />
                  Prescrição Médica
                </CardTitle>
                <CardDescription>
                  ID: {prescription.id.substring(0, 8)}...{prescription.id.substring(prescription.id.length - 8)}
                </CardDescription>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={handleDownloadPrescription}>
                  <Download className="h-4 w-4 mr-2" />
                  Baixar PDF
                </Button>
                <Link href={`/share/${prescription.id}`}>
                  <Button variant="outline" size="sm">
                    <Share2 className="h-4 w-4 mr-2" />
                    Compartilhar
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-lg mb-2">Informações do Médico</h3>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-gray-500">Nome</p>
                      <p className="font-medium">{prescription.doctorName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">CRM</p>
                      <p>{prescription.doctorCrm}</p>
                    </div>
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">Informações do Paciente</h3>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-gray-500">Nome</p>
                      <p className="font-medium">{prescription.patientName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">CPF</p>
                      <p>{prescription.patientCpf}</p>
                    </div>
                  </div>
                </div>
              </div>

              <Separator className="my-6" />

              <div>
                <h3 className="font-semibold text-lg mb-4">Detalhes da Prescrição</h3>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-500">Data</p>
                    <p>{prescription.date}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Medicamento</p>
                    <p className="font-medium">{prescription.medication}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Dosagem</p>
                    <p>{prescription.dosage}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Instruções</p>
                    <p className="whitespace-pre-line">{prescription.instructions}</p>
                  </div>
                </div>
              </div>

              <Separator className="my-6" />

              <div>
                <h3 className="font-semibold text-lg mb-4">Informações da Blockchain</h3>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-500">Hash da Transação</p>
                    <p className="font-mono text-sm break-all">{prescription.transactionHash}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Rede</p>
                    <p>Ethereum (Sepolia Testnet)</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Status de Verificação</p>
                    <div className="flex items-center mt-1">
                      {verificationStatus === "none" ? (
                        <Button
                          onClick={handleVerifyPrescription}
                          disabled={isVerifying}
                          className="bg-emerald-600 hover:bg-emerald-700"
                        >
                          {isVerifying ? "Verificando..." : "Verificar Autenticidade (ZK)"}
                        </Button>
                      ) : verificationStatus === "verifying" ? (
                        <p className="text-amber-500 flex items-center">
                          <span className="inline-block w-2 h-2 bg-amber-500 rounded-full mr-2 animate-pulse"></span>
                          Verificando...
                        </p>
                      ) : verificationStatus === "verified" ? (
                        <p className="text-emerald-600 flex items-center">
                          <span className="inline-block w-2 h-2 bg-emerald-600 rounded-full mr-2"></span>
                          Verificado com sucesso
                        </p>
                      ) : (
                        <p className="text-red-500 flex items-center">
                          <span className="inline-block w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                          Falha na verificação
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
