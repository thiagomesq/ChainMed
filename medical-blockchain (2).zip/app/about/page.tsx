import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Package2 } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center space-x-2">
            <Package2 className="h-6 w-6 text-emerald-500" />
            <h1 className="text-xl font-bold text-gray-900">MedChain</h1>
          </Link>
          <nav className="hidden md:flex space-x-4">
            <Link href="/" className="text-gray-600 hover:text-gray-900">
              Início
            </Link>
            <Link href="/about" className="text-emerald-600 font-medium">
              Sobre
            </Link>
            <Link href="/contact" className="text-gray-600 hover:text-gray-900">
              Contato
            </Link>
          </nav>
          <div className="flex space-x-2">
            <Link href="/login">
              <Button variant="outline">Entrar</Button>
            </Link>
            <Link href="/register">
              <Button>Cadastrar</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 bg-gray-50">
        <section className="py-12 md:py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl md:text-5xl font-bold text-center mb-8">Sobre o MedChain</h1>
            <div className="max-w-3xl mx-auto prose prose-emerald lg:prose-lg">
              <p className="lead text-xl text-gray-600 mb-8">
                MedChain é uma plataforma inovadora que utiliza tecnologia blockchain para criar um sistema seguro e
                transparente de prescrições médicas digitais.
              </p>

              <h2>Nossa Missão</h2>
              <p>
                Nossa missão é transformar a maneira como prescrições médicas são criadas, gerenciadas e compartilhadas,
                garantindo segurança, privacidade e facilidade de acesso para médicos e pacientes.
              </p>

              <h2>Tecnologia Blockchain</h2>
              <p>
                Utilizamos a blockchain Ethereum (rede Sepolia) para armazenar de forma segura e imutável todas as
                prescrições médicas. Isso garante que os registros não possam ser alterados ou falsificados, criando um
                histórico confiável de prescrições.
              </p>

              <h2>Validação com Zero-Knowledge Proofs</h2>
              <p>
                Nossa plataforma implementa Zero-Knowledge Proofs (ZK) para validação de prescrições, permitindo que a
                autenticidade de uma prescrição seja verificada sem revelar dados sensíveis. Isso adiciona uma camada
                extra de privacidade e segurança para todos os usuários.
              </p>

              <h2>Benefícios para Médicos</h2>
              <ul>
                <li>Criação rápida e segura de prescrições digitais</li>
                <li>Acesso ao histórico completo de prescrições de seus pacientes</li>
                <li>Redução de fraudes e falsificações</li>
                <li>Interface intuitiva e fácil de usar</li>
              </ul>

              <h2>Benefícios para Pacientes</h2>
              <ul>
                <li>Acesso a todas as suas prescrições em um só lugar</li>
                <li>Compartilhamento seguro com outros profissionais de saúde</li>
                <li>Garantia de autenticidade das prescrições</li>
                <li>Maior controle sobre seus dados médicos</li>
              </ul>

              <h2>Segurança e Privacidade</h2>
              <p>
                A segurança e privacidade dos dados são nossas principais prioridades. Todas as informações são
                criptografadas e armazenadas de forma segura na blockchain. Além disso, utilizamos carteiras digitais
                (como MetaMask) para autenticação, garantindo que apenas usuários autorizados tenham acesso às
                informações.
              </p>

              <div className="mt-12 text-center">
                <Link href="/register">
                  <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700">
                    Comece a usar agora
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-bold flex items-center">
                <Package2 className="h-5 w-5 mr-2 text-emerald-400" />
                MedChain
              </h2>
              <p className="text-gray-400 mt-2">Prescrições médicas seguras na blockchain</p>
            </div>
            <div className="flex space-x-4">
              <Link href="/terms" className="text-gray-400 hover:text-white">
                Termos
              </Link>
              <Link href="/privacy" className="text-gray-400 hover:text-white">
                Privacidade
              </Link>
              <Link href="/contact" className="text-gray-400 hover:text-white">
                Contato
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} MedChain. Todos os direitos reservados.
          </div>
        </div>
      </footer>
    </div>
  )
}
