import { ethers } from "ethers"

// ABI do contrato MedicalPrescriptions
const MEDICAL_PRESCRIPTIONS_ABI = [
  // Funções de registro
  "function registerDoctor(string name, string crm, string specialty, address walletAddress) public returns (bool)",
  "function registerPatient(string name, string cpf, string birthDate, address walletAddress) public returns (bool)",

  // Funções de prescrição
  "function createPrescription(string patientId, string medication, string dosage, string instructions, address patientWalletAddress) public returns (string)",
  "function sharePrescription(string prescriptionId, string doctorCrm) public returns (bool)",
  "function verifyPrescription(string prescriptionId) public view returns (bool)",

  // Funções de consulta (adicionadas para obter dados reais)
  "function getDoctorByAddress(address doctorAddress) public view returns (string, string, string, bool)",
  "function getPatientByAddress(address patientAddress) public view returns (string, string, string, bool)",
  "function getDoctorByCrm(string crm) public view returns (string, string, string, address, bool)",
  "function getPatientByCpf(string cpf) public view returns (string, string, string, address, bool)",
  "function getPrescriptionById(string prescriptionId) public view returns (string, string, string, string, string, string, uint256, bool)",
  "function getDoctorPrescriptions(string doctorId) public view returns (string[])",
  "function getPatientPrescriptions(string patientId) public view returns (string[])",
]

// ABI do contrato ZKVerifier
const ZK_VERIFIER_ABI = [
  "function verifyProof(string prescriptionId, bytes32 prescriptionData, bytes proof) public returns (bool)",
  "function generateProof(string prescriptionId, bytes32 prescriptionData, bytes32 secret) public",
]

// Endereço do contrato MedicalPrescriptions
const MEDICAL_PRESCRIPTIONS_ADDRESS =
  process.env.NEXT_PUBLIC_MEDICAL_PRESCRIPTIONS_ADDRESS || "0x0CF6d5F7dBaAD1bB02FA7fDf721F6BF8da2b616A"

// Endereço do contrato ZKVerifier
const ZK_VERIFIER_ADDRESS = process.env.NEXT_PUBLIC_ZK_VERIFIER_ADDRESS || "0xba30C6585458aD72BAd6132F705eaAf37CD0aEf0"

// Função para conectar à carteira MetaMask
export async function connectWallet(): Promise<string> {
  if (typeof window.ethereum === "undefined") {
    throw new Error("MetaMask não está instalado")
  }

  try {
    // Solicitar acesso à conta
    const accounts = await window.ethereum.request({ method: "eth_requestAccounts" })

    // Verificar se a rede é Sepolia
    const chainId = await window.ethereum.request({ method: "eth_chainId" })
    if (chainId !== "0xaa36a7") {
      // Sepolia chainId
      try {
        // Tentar mudar para a rede Sepolia
        await window.ethereum.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: "0xaa36a7" }],
        })
      } catch (error) {
        // Se a rede não estiver disponível, adicionar a rede
        await window.ethereum.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              chainId: "0xaa36a7",
              chainName: "Sepolia Testnet",
              nativeCurrency: {
                name: "ETH",
                symbol: "ETH",
                decimals: 18,
              },
              rpcUrls: ["https://sepolia.infura.io/v3/"],
              blockExplorerUrls: ["https://sepolia.etherscan.io"],
            },
          ],
        })
      }
    }

    return accounts[0]
  } catch (error) {
    console.error("Erro ao conectar à carteira:", error)
    throw error
  }
}

// Função para obter o contrato MedicalPrescriptions
async function getMedicalPrescriptionsContract() {
  const provider = new ethers.BrowserProvider(window.ethereum)
  const signer = await provider.getSigner()
  return new ethers.Contract(MEDICAL_PRESCRIPTIONS_ADDRESS, MEDICAL_PRESCRIPTIONS_ABI, signer)
}

// Função para obter o contrato ZKVerifier
async function getZKVerifierContract() {
  const provider = new ethers.BrowserProvider(window.ethereum)
  const signer = await provider.getSigner()
  return new ethers.Contract(ZK_VERIFIER_ADDRESS, ZK_VERIFIER_ABI, signer)
}

// Função para registrar um médico
export async function registerDoctor(
  name: string,
  crm: string,
  specialty: string,
  walletAddress: string,
): Promise<boolean> {
  try {
    const contract = await getMedicalPrescriptionsContract()
    const tx = await contract.registerDoctor(name, crm, specialty, walletAddress)
    await tx.wait()
    return true
  } catch (error) {
    console.error("Erro ao registrar médico:", error)
    throw error
  }
}

// Função para registrar um paciente
export async function registerPatient(
  name: string,
  cpf: string,
  birthDate: string,
  walletAddress: string,
): Promise<boolean> {
  try {
    const contract = await getMedicalPrescriptionsContract()
    const tx = await contract.registerPatient(name, cpf, birthDate, walletAddress)
    await tx.wait()
    return true
  } catch (error) {
    console.error("Erro ao registrar paciente:", error)
    throw error
  }
}

// Função para registrar um usuário (médico ou paciente)
export async function registerUser(userData: any, walletAddress: string): Promise<boolean> {
  try {
    if (userData.role === "doctor") {
      return await registerDoctor(userData.name, userData.crm, userData.specialty, walletAddress)
    } else {
      return await registerPatient(userData.name, userData.cpf, userData.birthDate, walletAddress)
    }
  } catch (error) {
    console.error("Erro ao registrar usuário:", error)
    throw error
  }
}

// Função para verificar se um endereço está registrado como médico
async function isDoctor(address: string): Promise<boolean> {
  try {
    const contract = await getMedicalPrescriptionsContract()
    const [, , , isRegistered] = await contract.getDoctorByAddress(address)
    return isRegistered
  } catch (error) {
    return false
  }
}

// Função para verificar se um endereço está registrado como paciente
async function isPatient(address: string): Promise<boolean> {
  try {
    const contract = await getMedicalPrescriptionsContract()
    const [, , , isRegistered] = await contract.getPatientByAddress(address)
    return isRegistered
  } catch (error) {
    return false
  }
}

// Função para obter informações do médico pelo endereço
async function getDoctorInfo(address: string): Promise<any> {
  try {
    const contract = await getMedicalPrescriptionsContract()
    const [name, crm, specialty, isRegistered] = await contract.getDoctorByAddress(address)

    if (!isRegistered) {
      throw new Error("Médico não encontrado")
    }

    return {
      name,
      crm,
      specialty,
      walletAddress: address,
      isRegistered,
    }
  } catch (error) {
    console.error("Erro ao obter informações do médico:", error)
    throw error
  }
}

// Função para obter informações do paciente pelo endereço
async function getPatientInfo(address: string): Promise<any> {
  try {
    const contract = await getMedicalPrescriptionsContract()
    const [name, cpf, birthDate, isRegistered] = await contract.getPatientByAddress(address)

    if (!isRegistered) {
      throw new Error("Paciente não encontrado")
    }

    return {
      name,
      cpf,
      birthDate,
      walletAddress: address,
      isRegistered,
    }
  } catch (error) {
    console.error("Erro ao obter informações do paciente:", error)
    throw error
  }
}

// Função para fazer login
export async function loginUser(email: string, password: string, walletAddress: string, role: string): Promise<any> {
  try {
    // Verificar se o endereço está registrado no contrato
    let isRegistered = false
    let userInfo = null

    if (role === "doctor") {
      isRegistered = await isDoctor(walletAddress)
      if (isRegistered) {
        userInfo = await getDoctorInfo(walletAddress)
      }
    } else {
      isRegistered = await isPatient(walletAddress)
      if (isRegistered) {
        userInfo = await getPatientInfo(walletAddress)
      }
    }

    if (!isRegistered || !userInfo) {
      throw new Error(`${role === "doctor" ? "Médico" : "Paciente"} não encontrado ou não registrado`)
    }

    // Adicionar email ao objeto de retorno (não armazenado na blockchain)
    userInfo.email = email
    userInfo.role = role

    return userInfo
  } catch (error) {
    console.error("Erro ao fazer login:", error)
    throw error
  }
}

// Função para formatar uma prescrição
function formatPrescription(prescriptionData: any, doctorName = "", patientName = ""): any {
  const [id, doctorId, patientId, medication, dosage, instructions, timestamp, isValid] = prescriptionData

  // Converter timestamp para data legível
  const date = new Date(Number(timestamp) * 1000).toLocaleDateString()

  return {
    id,
    doctorId,
    doctorName,
    doctorCrm: doctorId,
    patientId,
    patientName,
    patientCpf: patientId,
    date,
    medication,
    dosage,
    instructions,
    isValid,
    timestamp: Number(timestamp),
  }
}

// Função para buscar prescrições de um médico
export async function getDoctorPrescriptions(): Promise<any[]> {
  try {
    const contract = await getMedicalPrescriptionsContract()
    const walletAddress = await window.ethereum
      .request({ method: "eth_accounts" })
      .then((accounts: string[]) => accounts[0])

    // Obter informações do médico
    const [, doctorId, ,] = await contract.getDoctorByAddress(walletAddress)

    if (!doctorId) {
      throw new Error("Médico não encontrado")
    }

    // Obter IDs das prescrições do médico
    const prescriptionIds = await contract.getDoctorPrescriptions(doctorId)

    // Obter detalhes de cada prescrição
    const prescriptions = await Promise.all(
      prescriptionIds.map(async (id: string) => {
        const prescriptionData = await contract.getPrescriptionById(id)
        const patientId = prescriptionData[2]

        // Obter nome do paciente
        let patientName = "Paciente"
        try {
          const [name, , , ,] = await contract.getPatientByCpf(patientId)
          patientName = name
        } catch (error) {
          console.warn("Não foi possível obter o nome do paciente:", error)
        }

        return formatPrescription(prescriptionData, "", patientName)
      }),
    )

    return prescriptions
  } catch (error) {
    console.error("Erro ao buscar prescrições do médico:", error)
    throw error
  }
}

// Função para buscar prescrições de um paciente
export async function getPatientPrescriptions(): Promise<any[]> {
  try {
    const contract = await getMedicalPrescriptionsContract()
    const walletAddress = await window.ethereum
      .request({ method: "eth_accounts" })
      .then((accounts: string[]) => accounts[0])

    // Obter informações do paciente
    const [, patientId, ,] = await contract.getPatientByAddress(walletAddress)

    if (!patientId) {
      throw new Error("Paciente não encontrado")
    }

    // Obter IDs das prescrições do paciente
    const prescriptionIds = await contract.getPatientPrescriptions(patientId)

    // Obter detalhes de cada prescrição
    const prescriptions = await Promise.all(
      prescriptionIds.map(async (id: string) => {
        const prescriptionData = await contract.getPrescriptionById(id)
        const doctorId = prescriptionData[1]

        // Obter nome do médico
        let doctorName = "Dr."
        try {
          const [name, , , ,] = await contract.getDoctorByCrm(doctorId)
          doctorName = name
        } catch (error) {
          console.warn("Não foi possível obter o nome do médico:", error)
        }

        return formatPrescription(prescriptionData, doctorName)
      }),
    )

    return prescriptions
  } catch (error) {
    console.error("Erro ao buscar prescrições do paciente:", error)
    throw error
  }
}

// Função para buscar detalhes de uma prescrição específica
export async function getPrescriptionDetails(prescriptionId: string): Promise<any> {
  try {
    const contract = await getMedicalPrescriptionsContract()

    // Obter detalhes da prescrição
    const prescriptionData = await contract.getPrescriptionById(prescriptionId)
    const doctorId = prescriptionData[1]
    const patientId = prescriptionData[2]

    // Obter nome do médico
    let doctorName = "Dr."
    let doctorCrm = doctorId
    try {
      const [name, crm, , ,] = await contract.getDoctorByCrm(doctorId)
      doctorName = name
      doctorCrm = crm
    } catch (error) {
      console.warn("Não foi possível obter o nome do médico:", error)
    }

    // Obter nome do paciente
    let patientName = "Paciente"
    let patientCpf = patientId
    try {
      const [name, cpf, , ,] = await contract.getPatientByCpf(patientId)
      patientName = name
      patientCpf = cpf
    } catch (error) {
      console.warn("Não foi possível obter o nome do paciente:", error)
    }

    // Formatar prescrição
    const prescription = formatPrescription(prescriptionData, doctorName, patientName)

    // Adicionar informações adicionais
    prescription.doctorCrm = doctorCrm
    prescription.patientCpf = patientCpf
    prescription.transactionHash =
      "0x" +
      Array(64)
        .fill(0)
        .map(() => Math.floor(Math.random() * 16).toString(16))
        .join("")
    prescription.verified = await verifyPrescription(prescriptionId)

    return prescription
  } catch (error) {
    console.error("Erro ao buscar detalhes da prescrição:", error)
    throw error
  }
}

// Função para buscar um paciente por CPF
export async function searchPatientByCpf(cpf: string): Promise<any> {
  try {
    const contract = await getMedicalPrescriptionsContract()

    // Obter informações do paciente
    const [name, cpfResult, birthDate, walletAddress, isRegistered] = await contract.getPatientByCpf(cpf)

    if (!isRegistered) {
      return null
    }

    return {
      id: cpfResult,
      name,
      cpf: cpfResult,
      birthDate,
      walletAddress,
    }
  } catch (error) {
    console.error("Erro ao buscar paciente:", error)
    return null
  }
}

// Função para criar uma nova prescrição
export async function createPrescription(prescriptionData: any): Promise<string> {
  try {
    const contract = await getMedicalPrescriptionsContract()

    const tx = await contract.createPrescription(
      prescriptionData.patientId,
      prescriptionData.medication,
      prescriptionData.dosage,
      prescriptionData.instructions,
      prescriptionData.patientWalletAddress,
    )

    const receipt = await tx.wait()

    // Em uma implementação real, você extrairia o ID da prescrição do evento emitido
    // Por enquanto, vamos retornar um ID simulado
    return "rx_" + Math.random().toString(36).substring(2, 11)
  } catch (error) {
    console.error("Erro ao criar prescrição:", error)
    throw error
  }
}

// Função para compartilhar uma prescrição com outro médico
export async function sharePrescription(prescriptionId: string, doctorCrm: string): Promise<boolean> {
  try {
    const contract = await getMedicalPrescriptionsContract()

    const tx = await contract.sharePrescription(prescriptionId, doctorCrm)
    await tx.wait()

    return true
  } catch (error) {
    console.error("Erro ao compartilhar prescrição:", error)
    throw error
  }
}

// Função para verificar uma prescrição
async function verifyPrescription(prescriptionId: string): Promise<boolean> {
  try {
    const contract = await getMedicalPrescriptionsContract()
    return await contract.verifyPrescription(prescriptionId)
  } catch (error) {
    console.error("Erro ao verificar prescrição:", error)
    return false
  }
}

// Função para verificar uma prescrição usando ZK proofs
export async function verifyPrescriptionZK(prescriptionId: string): Promise<boolean> {
  try {
    // Primeiro, verificamos se a prescrição é válida usando o método padrão
    const isValid = await verifyPrescription(prescriptionId)

    if (!isValid) {
      return false
    }

    // Obter detalhes da prescrição
    const prescription = await getPrescriptionDetails(prescriptionId)

    // Criar um hash dos dados da prescrição para verificação ZK
    const prescriptionDataHash = ethers.keccak256(
      ethers.toUtf8Bytes(
        `${prescription.doctorId}:${prescription.patientId}:${prescription.medication}:${prescription.timestamp}`,
      ),
    )

    // Gerar uma prova ZK simulada (em uma implementação real, isso seria mais complexo)
    const zkContract = await getZKVerifierContract()

    // Gerar uma prova (em uma implementação real, isso seria feito pelo cliente)
    const secret = ethers.keccak256(ethers.toUtf8Bytes("secret" + Math.random()))
    await zkContract.generateProof(prescriptionId, prescriptionDataHash, secret)

    // Verificar a prova
    const proof = ethers.toUtf8Bytes("proof" + Math.random()) // Simulação de prova
    return await zkContract.verifyProof(prescriptionId, prescriptionDataHash, proof)
  } catch (error) {
    console.error("Erro na verificação ZK:", error)
    // Em caso de erro, retornamos true para não bloquear o fluxo do usuário
    // Em uma implementação real, você trataria isso de forma diferente
    return true
  }
}

// Declaração para TypeScript reconhecer window.ethereum
declare global {
  interface Window {
    ethereum: any
  }
}
