import { ethers } from "ethers"

// ABI do contrato MedicalPrescriptions
const MEDICAL_PRESCRIPTIONS_ABI = [
  {
    inputs: [
      {
        internalType: "string",
        name: "patientId",
        type: "string",
      },
      {
        internalType: "string",
        name: "medication",
        type: "string",
      },
      {
        internalType: "string",
        name: "dosage",
        type: "string",
      },
      {
        internalType: "string",
        name: "instructions",
        type: "string",
      },
      {
        internalType: "address",
        name: "patientWalletAddress",
        type: "address",
      },
    ],
    name: "createPrescription",
    outputs: [
      {
        internalType: "string",
        name: "",
        type: "string",
      },
    ],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "string",
        name: "crm",
        type: "string",
      },
      {
        indexed: false,
        internalType: "address",
        name: "walletAddress",
        type: "address",
      },
    ],
    name: "DoctorRegistered",
    type: "event",
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "string",
        name: "cpf",
        type: "string",
      },
      {
        indexed: false,
        internalType: "address",
        name: "walletAddress",
        type: "address",
      },
    ],
    name: "PatientRegistered",
    type: "event",
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "string",
        name: "prescriptionId",
        type: "string",
      },
      {
        indexed: false,
        internalType: "string",
        name: "doctorId",
        type: "string",
      },
      {
        indexed: false,
        internalType: "string",
        name: "patientId",
        type: "string",
      },
    ],
    name: "PrescriptionCreated",
    type: "event",
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "string",
        name: "prescriptionId",
        type: "string",
      },
      {
        indexed: false,
        internalType: "string",
        name: "doctorId",
        type: "string",
      },
    ],
    name: "PrescriptionShared",
    type: "event",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "name",
        type: "string",
      },
      {
        internalType: "string",
        name: "crm",
        type: "string",
      },
      {
        internalType: "string",
        name: "specialty",
        type: "string",
      },
      {
        internalType: "address",
        name: "walletAddress",
        type: "address",
      },
    ],
    name: "registerDoctor",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "name",
        type: "string",
      },
      {
        internalType: "string",
        name: "cpf",
        type: "string",
      },
      {
        internalType: "string",
        name: "birthDate",
        type: "string",
      },
      {
        internalType: "address",
        name: "walletAddress",
        type: "address",
      },
    ],
    name: "registerPatient",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "prescriptionId",
        type: "string",
      },
      {
        internalType: "string",
        name: "doctorCrm",
        type: "string",
      },
    ],
    name: "sharePrescription",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "prescriptionId",
        type: "string",
      },
    ],
    name: "verifyPrescription",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
]

// ABI do contrato ZKVerifier
const ZK_VERIFIER_ABI = [
  {
    inputs: [
      {
        internalType: "address",
        name: "_medicalPrescriptionsContract",
        type: "address",
      },
    ],
    stateMutability: "nonpayable",
    type: "constructor",
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "string",
        name: "prescriptionId",
        type: "string",
      },
      {
        indexed: false,
        internalType: "bool",
        name: "isValid",
        type: "bool",
      },
    ],
    name: "ProofVerified",
    type: "event",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "prescriptionId",
        type: "string",
      },
      {
        internalType: "bytes32",
        name: "prescriptionData",
        type: "bytes32",
      },
      {
        internalType: "bytes32",
        name: "secret",
        type: "bytes32",
      },
    ],
    name: "generateProof",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [],
    name: "medicalPrescriptionsContract",
    outputs: [
      {
        internalType: "address",
        name: "",
        type: "address",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "prescriptionId",
        type: "string",
      },
    ],
    name: "revokeProof",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "prescriptionId",
        type: "string",
      },
      {
        internalType: "bytes32",
        name: "prescriptionData",
        type: "bytes32",
      },
      {
        internalType: "bytes",
        name: "proof",
        type: "bytes",
      },
    ],
    name: "verifyProof",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool",
      },
    ],
    stateMutability: "nonpayable",
    type: "function",
  },
]

// Endereço do contrato MedicalPrescriptions
const MEDICAL_PRESCRIPTIONS_ADDRESS =
  process.env.NEXT_PUBLIC_MEDICAL_PRESCRIPTIONS_ADDRESS || "0x0CF6d5F7dBaAD1bB02FA7fDf721F6BF8da2b616A"

// Endereço do contrato ZKVerifier
const ZK_VERIFIER_ADDRESS = process.env.NEXT_PUBLIC_ZK_VERIFIER_ADDRESS || "0xba30C6585458aD72BAd6132F705eaAf37CD0aEf0"

// Função para obter o contrato MedicalPrescriptions
export async function getMedicalPrescriptionsContract() {
  if (typeof window === "undefined" || !window.ethereum) {
    throw new Error("MetaMask não está disponível")
  }

  const provider = new ethers.BrowserProvider(window.ethereum)
  const signer = await provider.getSigner()
  return new ethers.Contract(MEDICAL_PRESCRIPTIONS_ADDRESS, MEDICAL_PRESCRIPTIONS_ABI, signer)
}

// Função para obter o contrato ZKVerifier
export async function getZKVerifierContract() {
  if (typeof window === "undefined" || !window.ethereum) {
    throw new Error("MetaMask não está disponível")
  }

  const provider = new ethers.BrowserProvider(window.ethereum)
  const signer = await provider.getSigner()
  return new ethers.Contract(ZK_VERIFIER_ADDRESS, ZK_VERIFIER_ABI, signer)
}

// Declaração para TypeScript reconhecer window.ethereum
declare global {
  interface Window {
    ethereum: any
  }
}
