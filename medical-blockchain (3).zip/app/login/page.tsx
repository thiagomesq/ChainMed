"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { connectWallet, loginUser } from "@/lib/blockchain"
import { Loader2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

const formSchema = z.object({
  email: z.string().email({ message: "Email inválido" }),
  password: z.string().min(1, { message: "Senha é obrigatória" }),
  role: z.enum(["doctor", "patient"]),
})

export default function LoginPage() {
  const router = useRouter()
  const [isConnecting, setIsConnecting] = useState(false)
  const [walletConnected, setWalletConnected] = useState(false)
  const [walletAddress, setWalletAddress] = useState("")
  const [isLoggingIn, setIsLoggingIn] = useState(false)
  const [loginError, setLoginError] = useState("")

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
      role: "patient",
    },
  })

  const handleConnectWallet = async () => {
    setIsConnecting(true)
    setLoginError("")
    try {
      const address = await connectWallet()
      setWalletAddress(address)
      setWalletConnected(true)
      toast({
        title: "Carteira conectada",
        description: `Endereço: ${address.substring(0, 6)}...${address.substring(address.length - 4)}`,
      })
    } catch (error: any) {
      console.error("Failed to connect wallet:", error)
      setLoginError(`Erro ao conectar carteira: ${error.message || "Verifique se o MetaMask está instalado"}`)
      toast({
        title: "Erro ao conectar carteira",
        description: error.message || "Certifique-se de que você tem o MetaMask instalado.",
        variant: "destructive",
      })
    } finally {
      setIsConnecting(false)
    }
  }

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    if (!walletConnected) {
      setLoginError("Por favor, conecte sua carteira antes de fazer login.")
      toast({
        title: "Carteira não conectada",
        description: "Por favor, conecte sua carteira antes de fazer login.",
        variant: "destructive",
      })
      return
    }

    setIsLoggingIn(true)
    setLoginError("")
    try {
      // Fazer login usando a carteira e o papel selecionado
      const userInfo = await loginUser(values.email, values.password, walletAddress, values.role)

      toast({
        title: "Login bem-sucedido",
        description: `Bem-vindo, ${userInfo.name}!`,
      })

      // Armazenar informações do usuário no localStorage (opcional)
      localStorage.setItem("userInfo", JSON.stringify(userInfo))

      // Redirecionar para a página de dashboard após o login bem-sucedido
      router.push(`/dashboard/${values.role}`)
    } catch (error: any) {
      console.error("Login failed:", error)
      setLoginError(error.message || "Falha no login. Verifique suas credenciais e tente novamente.")
      toast({
        title: "Falha no login",
        description: error.message || "Verifique suas credenciais e tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsLoggingIn(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">Entrar</h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Não tem uma conta?{" "}
          <Link href="/register" className="font-medium text-emerald-600 hover:text-emerald-500">
            Cadastre-se
          </Link>
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <Card>
          <CardHeader>
            <CardTitle>Login</CardTitle>
            <CardDescription>Entre com suas credenciais para acessar sua conta</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <Button
                onClick={handleConnectWallet}
                variant="outline"
                className="w-full"
                disabled={isConnecting || walletConnected}
              >
                {isConnecting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Conectando...
                  </>
                ) : walletConnected ? (
                  <>
                    Carteira Conectada: {walletAddress.substring(0, 6)}...
                    {walletAddress.substring(walletAddress.length - 4)}
                  </>
                ) : (
                  <>Conectar Carteira (MetaMask)</>
                )}
              </Button>
            </div>

            {loginError && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-600 rounded-md text-sm">
                {loginError}
              </div>
            )}

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="space-y-2 mb-4">
                  <label className="text-sm font-medium">Tipo de Usuário</label>
                  <div className="flex space-x-4">
                    <div className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id="patient-login"
                        name="role"
                        value="patient"
                        checked={form.watch("role") === "patient"}
                        onChange={() => form.setValue("role", "patient")}
                        className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                      />
                      <label htmlFor="patient-login" className="text-sm font-medium text-gray-700">
                        Paciente
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id="doctor-login"
                        name="role"
                        value="doctor"
                        checked={form.watch("role") === "doctor"}
                        onChange={() => form.setValue("role", "doctor")}
                        className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                      />
                      <label htmlFor="doctor-login" className="text-sm font-medium text-gray-700">
                        Médico
                      </label>
                    </div>
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="seu@email.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Senha</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="******" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full" disabled={isLoggingIn || !walletConnected}>
                  {isLoggingIn ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Entrando...
                    </>
                  ) : (
                    "Entrar"
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Link href="/forgot-password" className="text-sm text-emerald-600 hover:text-emerald-500">
              Esqueceu sua senha?
            </Link>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
