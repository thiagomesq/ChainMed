import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6 text-emerald-500"
            >
              <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
            </svg>
            <h1 className="text-xl font-bold text-gray-900">MedChain</h1>
          </div>
          <nav className="hidden md:flex space-x-4">
            <Link href="/about" className="text-gray-600 hover:text-gray-900">
              Sobre
            </Link>
            <Link href="/contact" className="text-gray-600 hover:text-gray-900">
              Contato
            </Link>
          </nav>
          <div className="flex space-x-2">
            <Link href="/login">
              <Button variant="outline">Entrar</Button>
            </Link>
            <Link href="/register">
              <Button>Cadastrar</Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1 bg-gray-50">
        <section className="py-12 md:py-24">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">Prescrições Médicas na Blockchain</h2>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Uma plataforma segura e transparente para médicos e pacientes gerenciarem prescrições médicas utilizando
              tecnologia blockchain.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/register?role=doctor">
                <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700">
                  Sou Médico
                </Button>
              </Link>
              <Link href="/register?role=patient">
                <Button size="lg" variant="outline" className="border-emerald-600 text-emerald-600 hover:bg-emerald-50">
                  Sou Paciente
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">Como Funciona</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Registro Seguro</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>
                    Médicos e pacientes se cadastram com verificação de identidade utilizando tecnologia blockchain.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Prescrições Digitais</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>
                    Médicos criam prescrições digitais que são armazenadas de forma segura e imutável na blockchain.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Compartilhamento Controlado</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>Pacientes podem compartilhar suas prescrições com outros médicos de forma segura e controlada.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-24 bg-emerald-50">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-8">Tecnologias Utilizadas</h2>
            <div className="flex flex-wrap justify-center gap-6 mb-8">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-semibold">Ethereum (Sepolia)</h3>
                <p className="text-sm text-gray-600">Rede de teste segura</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-semibold">Zero-Knowledge Proofs</h3>
                <p className="text-sm text-gray-600">Validação privada</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-semibold">Smart Contracts</h3>
                <p className="text-sm text-gray-600">Contratos inteligentes</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-semibold">Node.js</h3>
                <p className="text-sm text-gray-600">Backend robusto</p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-bold flex items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5 mr-2 text-emerald-400"
                >
                  <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                </svg>
                MedChain
              </h2>
              <p className="text-gray-400 mt-2">Prescrições médicas seguras na blockchain</p>
            </div>
            <div className="flex space-x-4">
              <Link href="/terms" className="text-gray-400 hover:text-white">
                Termos
              </Link>
              <Link href="/privacy" className="text-gray-400 hover:text-white">
                Privacidade
              </Link>
              <Link href="/contact" className="text-gray-400 hover:text-white">
                Contato
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} MedChain. Todos os direitos reservados.
          </div>
        </div>
      </footer>
    </div>
  )
}
