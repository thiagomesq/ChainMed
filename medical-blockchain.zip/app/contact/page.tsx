"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Package2, Mail, Phone, MapPin, Send, Loader2 } from "lucide-react"

export default function ContactPage() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulação de envio do formulário
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)
    setIsSubmitted(true)
    setFormData({
      name: "",
      email: "",
      subject: "",
      message: "",
    })
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center space-x-2">
            <Package2 className="h-6 w-6 text-emerald-500" />
            <h1 className="text-xl font-bold text-gray-900">MedChain</h1>
          </Link>
          <nav className="hidden md:flex space-x-4">
            <Link href="/" className="text-gray-600 hover:text-gray-900">
              Início
            </Link>
            <Link href="/about" className="text-gray-600 hover:text-gray-900">
              Sobre
            </Link>
            <Link href="/contact" className="text-emerald-600 font-medium">
              Contato
            </Link>
          </nav>
          <div className="flex space-x-2">
            <Link href="/login">
              <Button variant="outline">Entrar</Button>
            </Link>
            <Link href="/register">
              <Button>Cadastrar</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 bg-gray-50">
        <section className="py-12 md:py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl md:text-5xl font-bold text-center mb-8">Entre em Contato</h1>
            <p className="text-xl text-gray-600 text-center mb-12 max-w-3xl mx-auto">
              Tem alguma dúvida ou sugestão? Nossa equipe está pronta para ajudar. Preencha o formulário abaixo ou use
              um de nossos canais de contato.
            </p>

            <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              <div className="md:col-span-1 space-y-6">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-start space-x-4">
                      <Mail className="h-6 w-6 text-emerald-500 mt-1" />
                      <div>
                        <h3 className="font-medium">Email</h3>
                        <p className="text-gray-600">contato@medchain.com.br</p>
                        <p className="text-gray-600">suporte@medchain.com.br</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-start space-x-4">
                      <Phone className="h-6 w-6 text-emerald-500 mt-1" />
                      <div>
                        <h3 className="font-medium">Telefone</h3>
                        <p className="text-gray-600">(11) 3456-7890</p>
                        <p className="text-gray-600">(11) 98765-4321</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-start space-x-4">
                      <MapPin className="h-6 w-6 text-emerald-500 mt-1" />
                      <div>
                        <h3 className="font-medium">Endereço</h3>
                        <p className="text-gray-600">Av. Paulista, 1000</p>
                        <p className="text-gray-600">São Paulo, SP - Brasil</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="md:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Formulário de Contato</CardTitle>
                    <CardDescription>
                      Preencha o formulário abaixo e entraremos em contato o mais breve possível.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isSubmitted ? (
                      <div className="text-center py-8">
                        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-100 mb-4">
                          <Send className="h-8 w-8 text-emerald-600" />
                        </div>
                        <h3 className="text-xl font-medium mb-2">Mensagem Enviada!</h3>
                        <p className="text-gray-600 mb-4">
                          Obrigado por entrar em contato. Responderemos o mais breve possível.
                        </p>
                        <Button variant="outline" onClick={() => setIsSubmitted(false)} className="mt-2">
                          Enviar outra mensagem
                        </Button>
                      </div>
                    ) : (
                      <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label htmlFor="name" className="text-sm font-medium">
                              Nome Completo
                            </label>
                            <Input
                              id="name"
                              name="name"
                              placeholder="Seu nome completo"
                              value={formData.name}
                              onChange={handleChange}
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <label htmlFor="email" className="text-sm font-medium">
                              Email
                            </label>
                            <Input
                              id="email"
                              name="email"
                              type="email"
                              placeholder="seu@email.com"
                              value={formData.email}
                              onChange={handleChange}
                              required
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label htmlFor="subject" className="text-sm font-medium">
                            Assunto
                          </label>
                          <Input
                            id="subject"
                            name="subject"
                            placeholder="Assunto da mensagem"
                            value={formData.subject}
                            onChange={handleChange}
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <label htmlFor="message" className="text-sm font-medium">
                            Mensagem
                          </label>
                          <Textarea
                            id="message"
                            name="message"
                            placeholder="Digite sua mensagem aqui..."
                            rows={6}
                            value={formData.message}
                            onChange={handleChange}
                            required
                          />
                        </div>

                        <Button
                          type="submit"
                          className="w-full bg-emerald-600 hover:bg-emerald-700"
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Enviando...
                            </>
                          ) : (
                            "Enviar Mensagem"
                          )}
                        </Button>
                      </form>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-bold flex items-center">
                <Package2 className="h-5 w-5 mr-2 text-emerald-400" />
                MedChain
              </h2>
              <p className="text-gray-400 mt-2">Prescrições médicas seguras na blockchain</p>
            </div>
            <div className="flex space-x-4">
              <Link href="/terms" className="text-gray-400 hover:text-white">
                Termos
              </Link>
              <Link href="/privacy" className="text-gray-400 hover:text-white">
                Privacidade
              </Link>
              <Link href="/contact" className="text-gray-400 hover:text-white">
                Contato
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} MedChain. Todos os direitos reservados.
          </div>
        </div>
      </footer>
    </div>
  )
}
