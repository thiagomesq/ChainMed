"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Bell, FileText, LogOut, Package2, Search, Settings, Share2, User } from "lucide-react"
import { getPatientPrescriptions, sharePrescription } from "@/lib/blockchain"

// Tipo para prescrições
interface Prescription {
  id: string
  doctorName: string
  doctorCrm: string
  date: string
  medication: string
  dosage: string
  instructions: string
}

export default function PatientDashboard() {
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(null)
  const [doctorCrm, setDoctorCrm] = useState("")
  const [isSharing, setIsSharing] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)

  // Carregar prescrições do paciente
  useEffect(() => {
    const loadPrescriptions = async () => {
      try {
        const data = await getPatientPrescriptions()
        setPrescriptions(data)
      } catch (error) {
        console.error("Failed to load prescriptions:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadPrescriptions()
  }, [])

  // Filtrar prescrições com base no termo de busca
  const filteredPrescriptions = prescriptions.filter(
    (prescription) =>
      prescription.doctorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prescription.doctorCrm.includes(searchTerm) ||
      prescription.medication.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Compartilhar prescrição com outro médico
  const handleSharePrescription = async () => {
    if (!selectedPrescription || !doctorCrm) {
      alert("Por favor, preencha o CRM do médico")
      return
    }

    setIsSharing(true)
    try {
      await sharePrescription(selectedPrescription.id, doctorCrm)
      alert("Prescrição compartilhada com sucesso!")
      setDialogOpen(false)
      setDoctorCrm("")
    } catch (error) {
      console.error("Failed to share prescription:", error)
      alert("Erro ao compartilhar prescrição")
    } finally {
      setIsSharing(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Package2 className="h-6 w-6 text-emerald-500" />
            <h1 className="text-xl font-bold text-gray-900">MedChain</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
            <Link href="/login">
              <Button variant="ghost" size="icon">
                <LogOut className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        <aside className="w-64 border-r bg-gray-50 hidden md:block">
          <div className="p-4">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">
                <User className="h-6 w-6 text-emerald-600" />
              </div>
              <div>
                <p className="font-medium">Maria Santos</p>
                <p className="text-sm text-gray-500">Paciente</p>
              </div>
            </div>
            <nav className="space-y-1">
              <Link
                href="/dashboard/patient"
                className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-emerald-50 text-emerald-700"
              >
                <FileText className="h-5 w-5" />
                <span>Minhas Prescrições</span>
              </Link>
              <Link
                href="#"
                className="flex items-center space-x-2 px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-100"
              >
                <Settings className="h-5 w-5" />
                <span>Configurações</span>
              </Link>
            </nav>
          </div>
        </aside>

        <main className="flex-1 p-6 bg-gray-50">
          <div className="max-w-6xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold text-gray-900">Minhas Prescrições Médicas</h1>
            </div>

            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  className="pl-10"
                  placeholder="Buscar prescrições por médico, CRM ou medicamento"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>

            <Tabs defaultValue="all">
              <TabsList className="mb-4">
                <TabsTrigger value="all">Todas</TabsTrigger>
                <TabsTrigger value="recent">Recentes</TabsTrigger>
              </TabsList>

              <TabsContent value="all">
                <Card>
                  <CardContent className="p-0">
                    {isLoading ? (
                      <div className="p-6 text-center">Carregando prescrições...</div>
                    ) : filteredPrescriptions.length === 0 ? (
                      <div className="p-6 text-center text-gray-500">
                        {searchTerm ? "Nenhuma prescrição encontrada" : "Você ainda não tem nenhuma prescrição"}
                      </div>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Médico</TableHead>
                            <TableHead>CRM</TableHead>
                            <TableHead>Medicamento</TableHead>
                            <TableHead>Data</TableHead>
                            <TableHead>Ações</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredPrescriptions.map((prescription) => (
                            <TableRow key={prescription.id}>
                              <TableCell className="font-medium">{prescription.doctorName}</TableCell>
                              <TableCell>{prescription.doctorCrm}</TableCell>
                              <TableCell>{prescription.medication}</TableCell>
                              <TableCell>{prescription.date}</TableCell>
                              <TableCell className="flex space-x-2">
                                <Link href={`/prescriptions/${prescription.id}`}>
                                  <Button variant="ghost" size="sm">
                                    Ver Detalhes
                                  </Button>
                                </Link>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedPrescription(prescription)
                                    setDialogOpen(true)
                                  }}
                                >
                                  <Share2 className="h-4 w-4 mr-1" />
                                  Compartilhar
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="recent">
                <Card>
                  <CardContent className="p-0">
                    {isLoading ? (
                      <div className="p-6 text-center">Carregando prescrições...</div>
                    ) : filteredPrescriptions.length === 0 ? (
                      <div className="p-6 text-center text-gray-500">Nenhuma prescrição recente encontrada</div>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Médico</TableHead>
                            <TableHead>CRM</TableHead>
                            <TableHead>Medicamento</TableHead>
                            <TableHead>Data</TableHead>
                            <TableHead>Ações</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredPrescriptions
                            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                            .slice(0, 5)
                            .map((prescription) => (
                              <TableRow key={prescription.id}>
                                <TableCell className="font-medium">{prescription.doctorName}</TableCell>
                                <TableCell>{prescription.doctorCrm}</TableCell>
                                <TableCell>{prescription.medication}</TableCell>
                                <TableCell>{prescription.date}</TableCell>
                                <TableCell className="flex space-x-2">
                                  <Link href={`/prescriptions/${prescription.id}`}>
                                    <Button variant="ghost" size="sm">
                                      Ver Detalhes
                                    </Button>
                                  </Link>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => {
                                      setSelectedPrescription(prescription)
                                      setDialogOpen(true)
                                    }}
                                  >
                                    <Share2 className="h-4 w-4 mr-1" />
                                    Compartilhar
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Compartilhar Prescrição</DialogTitle>
            <DialogDescription>Compartilhe esta prescrição com outro médico informando o CRM.</DialogDescription>
          </DialogHeader>

          {selectedPrescription && (
            <div className="p-2 border rounded-md bg-gray-50 mb-4">
              <p className="font-medium">Médico: {selectedPrescription.doctorName}</p>
              <p className="text-sm">Medicamento: {selectedPrescription.medication}</p>
              <p className="text-sm text-gray-500">Data: {selectedPrescription.date}</p>
            </div>
          )}

          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="crm" className="text-right">
                CRM do Médico
              </label>
              <Input
                id="crm"
                placeholder="Digite o CRM do médico"
                className="col-span-3"
                value={doctorCrm}
                onChange={(e) => setDoctorCrm(e.target.value)}
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              onClick={handleSharePrescription}
              disabled={isSharing || !doctorCrm}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {isSharing ? "Compartilhando..." : "Compartilhar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
