import { ethers } from "ethers"

// ABI do contrato MedicalPrescriptions
// Ajustado para corresponder melhor ao contrato real
const MEDICAL_PRESCRIPTIONS_ABI = [
  // Funções de registro
  "function registerDoctor(string name, string crm, string specialty, address walletAddress) public returns (bool)",
  "function registerPatient(string name, string cpf, string birthDate, address walletAddress) public returns (bool)",

  // Funções de consulta de usuários
  "function doctors(string) public view returns (string name, string crm, string specialty, address walletAddress, bool isRegistered)",
  "function patients(string) public view returns (string name, string cpf, string birthDate, address walletAddress, bool isRegistered)",
  "function doctorAddresses(address) public view returns (string)",
  "function patientAddresses(address) public view returns (string)",

  // Funções de prescrição
  "function createPrescription(string patientId, string medication, string dosage, string instructions, address patientWalletAddress) public returns (string)",
  "function sharePrescription(string prescriptionId, string doctorCrm) public returns (bool)",
  "function verifyPrescription(string prescriptionId) public view returns (bool)",

  // Funções de consulta de prescrições
  "function prescriptions(string) public view returns (string id, string doctorId, string patientId, string medication, string dosage, string instructions, uint256 timestamp, bool isValid)",
  "function doctorPrescriptions(string, string) public view returns (bool)",
  "function patientPrescriptions(string, string) public view returns (bool)",

  // Eventos
  "event DoctorRegistered(string crm, address walletAddress)",
  "event PatientRegistered(string cpf, address walletAddress)",
  "event PrescriptionCreated(string prescriptionId, string doctorId, string patientId)",
  "event PrescriptionShared(string prescriptionId, string doctorId)",
]

// ABI do contrato ZKVerifier
const ZK_VERIFIER_ABI = [
  "function verifyProof(string prescriptionId, bytes32 prescriptionData, bytes proof) public returns (bool)",
  "function generateProof(string prescriptionId, bytes32 prescriptionData, bytes32 secret) public",
  "event ProofVerified(string prescriptionId, bool isValid)",
]

// Endereço do contrato MedicalPrescriptions
const MEDICAL_PRESCRIPTIONS_ADDRESS =
  process.env.NEXT_PUBLIC_MEDICAL_PRESCRIPTIONS_ADDRESS || "0x0CF6d5F7dBaAD1bB02FA7fDf721F6BF8da2b616A"

// Endereço do contrato ZKVerifier
const ZK_VERIFIER_ADDRESS = process.env.NEXT_PUBLIC_ZK_VERIFIER_ADDRESS || "0xba30C6585458aD72BAd6132F705eaAf37CD0aEf0"

// Função para conectar à carteira MetaMask
export async function connectWallet(): Promise<string> {
  if (typeof window.ethereum === "undefined") {
    throw new Error("MetaMask não está instalado")
  }

  try {
    // Solicitar acesso à conta
    const accounts = await window.ethereum.request({ method: "eth_requestAccounts" })

    // Verificar se a rede é Sepolia
    const chainId = await window.ethereum.request({ method: "eth_chainId" })
    if (chainId !== "0xaa36a7") {
      // Sepolia chainId
      try {
        // Tentar mudar para a rede Sepolia
        await window.ethereum.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: "0xaa36a7" }],
        })
      } catch (error) {
        // Se a rede não estiver disponível, adicionar a rede
        await window.ethereum.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              chainId: "0xaa36a7",
              chainName: "Sepolia Testnet",
              nativeCurrency: {
                name: "ETH",
                symbol: "ETH",
                decimals: 18,
              },
              rpcUrls: ["https://sepolia.infura.io/v3/"],
              blockExplorerUrls: ["https://sepolia.etherscan.io"],
            },
          ],
        })
      }
    }

    return accounts[0]
  } catch (error) {
    console.error("Erro ao conectar à carteira:", error)
    throw error
  }
}

// Função para obter o contrato MedicalPrescriptions
async function getMedicalPrescriptionsContract() {
  const provider = new ethers.BrowserProvider(window.ethereum)
  const signer = await provider.getSigner()
  return new ethers.Contract(MEDICAL_PRESCRIPTIONS_ADDRESS, MEDICAL_PRESCRIPTIONS_ABI, signer)
}

// Função para obter o contrato ZKVerifier
async function getZKVerifierContract() {
  const provider = new ethers.BrowserProvider(window.ethereum)
  const signer = await provider.getSigner()
  return new ethers.Contract(ZK_VERIFIER_ADDRESS, ZK_VERIFIER_ABI, signer)
}

// Função para registrar um médico
export async function registerDoctor(
  name: string,
  crm: string,
  specialty: string,
  walletAddress: string,
): Promise<boolean> {
  try {
    console.log(`Registrando médico: ${name}, CRM: ${crm}, Especialidade: ${specialty}, Endereço: ${walletAddress}`)
    const contract = await getMedicalPrescriptionsContract()

    // Verificar se o médico já está registrado
    try {
      const doctorId = await contract.doctorAddresses(walletAddress)
      console.log("Verificação de médico existente:", doctorId)
      if (doctorId && doctorId !== "") {
        console.log("Médico já registrado com este endereço")
        return true
      }
    } catch (error) {
      console.log("Médico não encontrado, prosseguindo com o registro")
    }

    // Registrar o médico
    const tx = await contract.registerDoctor(name, crm, specialty, walletAddress)
    console.log("Transação enviada:", tx.hash)

    const receipt = await tx.wait()
    console.log("Transação confirmada:", receipt)

    return true
  } catch (error) {
    console.error("Erro ao registrar médico:", error)
    throw error
  }
}

// Função para registrar um paciente
export async function registerPatient(
  name: string,
  cpf: string,
  birthDate: string,
  walletAddress: string,
): Promise<boolean> {
  try {
    console.log(
      `Registrando paciente: ${name}, CPF: ${cpf}, Data de Nascimento: ${birthDate}, Endereço: ${walletAddress}`,
    )
    const contract = await getMedicalPrescriptionsContract()

    // Verificar se o paciente já está registrado
    try {
      const patientId = await contract.patientAddresses(walletAddress)
      console.log("Verificação de paciente existente:", patientId)
      if (patientId && patientId !== "") {
        console.log("Paciente já registrado com este endereço")
        return true
      }
    } catch (error) {
      console.log("Paciente não encontrado, prosseguindo com o registro")
    }

    // Registrar o paciente
    const tx = await contract.registerPatient(name, cpf, birthDate, walletAddress)
    console.log("Transação enviada:", tx.hash)

    const receipt = await tx.wait()
    console.log("Transação confirmada:", receipt)

    return true
  } catch (error) {
    console.error("Erro ao registrar paciente:", error)
    throw error
  }
}

// Função para registrar um usuário (médico ou paciente)
export async function registerUser(userData: any, walletAddress: string): Promise<boolean> {
  try {
    console.log("Registrando usuário:", userData)
    if (userData.role === "doctor") {
      return await registerDoctor(userData.name, userData.crm, userData.specialty, walletAddress)
    } else {
      return await registerPatient(userData.name, userData.cpf, userData.birthDate, walletAddress)
    }
  } catch (error) {
    console.error("Erro ao registrar usuário:", error)
    throw error
  }
}

// Função para verificar se um endereço está registrado como médico
async function isDoctor(address: string): Promise<{ isRegistered: boolean; doctorId: string }> {
  try {
    console.log("Verificando se o endereço é de um médico:", address)
    const contract = await getMedicalPrescriptionsContract()

    // Obter o ID do médico pelo endereço
    const doctorId = await contract.doctorAddresses(address)
    console.log("ID do médico:", doctorId)

    if (!doctorId || doctorId === "") {
      return { isRegistered: false, doctorId: "" }
    }

    // Obter detalhes do médico pelo ID
    const doctor = await contract.doctors(doctorId)
    console.log("Detalhes do médico:", doctor)

    return {
      isRegistered: doctor.isRegistered,
      doctorId,
    }
  } catch (error) {
    console.error("Erro ao verificar se é médico:", error)
    return { isRegistered: false, doctorId: "" }
  }
}

// Função para verificar se um endereço está registrado como paciente
async function isPatient(address: string): Promise<{ isRegistered: boolean; patientId: string }> {
  try {
    console.log("Verificando se o endereço é de um paciente:", address)
    const contract = await getMedicalPrescriptionsContract()

    // Obter o ID do paciente pelo endereço
    const patientId = await contract.patientAddresses(address)
    console.log("ID do paciente:", patientId)

    if (!patientId || patientId === "") {
      return { isRegistered: false, patientId: "" }
    }

    // Obter detalhes do paciente pelo ID
    const patient = await contract.patients(patientId)
    console.log("Detalhes do paciente:", patient)

    return {
      isRegistered: patient.isRegistered,
      patientId,
    }
  } catch (error) {
    console.error("Erro ao verificar se é paciente:", error)
    return { isRegistered: false, patientId: "" }
  }
}

// Função para obter informações do médico pelo ID
async function getDoctorInfo(doctorId: string): Promise<any> {
  try {
    console.log("Obtendo informações do médico pelo ID:", doctorId)
    const contract = await getMedicalPrescriptionsContract()

    // Obter detalhes do médico
    const doctor = await contract.doctors(doctorId)
    console.log("Detalhes do médico:", doctor)

    if (!doctor.isRegistered) {
      throw new Error("Médico não encontrado")
    }

    return {
      name: doctor.name,
      crm: doctor.crm,
      specialty: doctor.specialty,
      walletAddress: doctor.walletAddress,
      isRegistered: doctor.isRegistered,
    }
  } catch (error) {
    console.error("Erro ao obter informações do médico:", error)
    throw error
  }
}

// Função para obter informações do paciente pelo ID
async function getPatientInfo(patientId: string): Promise<any> {
  try {
    console.log("Obtendo informações do paciente pelo ID:", patientId)
    const contract = await getMedicalPrescriptionsContract()

    // Obter detalhes do paciente
    const patient = await contract.patients(patientId)
    console.log("Detalhes do paciente:", patient)

    if (!patient.isRegistered) {
      throw new Error("Paciente não encontrado")
    }

    return {
      name: patient.name,
      cpf: patient.cpf,
      birthDate: patient.birthDate,
      walletAddress: patient.walletAddress,
      isRegistered: patient.isRegistered,
    }
  } catch (error) {
    console.error("Erro ao obter informações do paciente:", error)
    throw error
  }
}

// Função para fazer login
export async function loginUser(email: string, password: string, walletAddress: string, role: string): Promise<any> {
  try {
    console.log(`Tentando login como ${role} com endereço: ${walletAddress}`)

    // Verificar se o endereço está registrado no contrato
    let userInfo = null

    if (role === "doctor") {
      const { isRegistered, doctorId } = await isDoctor(walletAddress)
      console.log(`Resultado da verificação de médico: isRegistered=${isRegistered}, doctorId=${doctorId}`)

      if (isRegistered && doctorId) {
        userInfo = await getDoctorInfo(doctorId)
      }
    } else {
      const { isRegistered, patientId } = await isPatient(walletAddress)
      console.log(`Resultado da verificação de paciente: isRegistered=${isRegistered}, patientId=${patientId}`)

      if (isRegistered && patientId) {
        userInfo = await getPatientInfo(patientId)
      }
    }

    if (!userInfo) {
      throw new Error(`${role === "doctor" ? "Médico" : "Paciente"} não encontrado ou não registrado`)
    }

    // Adicionar email ao objeto de retorno (não armazenado na blockchain)
    userInfo.email = email
    userInfo.role = role

    console.log("Login bem-sucedido:", userInfo)
    return userInfo
  } catch (error) {
    console.error("Erro ao fazer login:", error)
    throw error
  }
}

// Função para formatar uma prescrição
function formatPrescription(prescriptionData: any, doctorName = "", patientName = ""): any {
  const [id, doctorId, patientId, medication, dosage, instructions, timestamp, isValid] = prescriptionData

  // Converter timestamp para data legível
  const date = new Date(Number(timestamp) * 1000).toLocaleDateString()

  return {
    id,
    doctorId,
    doctorName,
    doctorCrm: doctorId,
    patientId,
    patientName,
    patientCpf: patientId,
    date,
    medication,
    dosage,
    instructions,
    isValid,
    timestamp: Number(timestamp),
  }
}

// Função para buscar prescrições de um médico
export async function getDoctorPrescriptions(): Promise<any[]> {
  try {
    console.log("Buscando prescrições do médico")
    const contract = await getMedicalPrescriptionsContract()
    const walletAddress = await window.ethereum
      .request({ method: "eth_accounts" })
      .then((accounts: string[]) => accounts[0])

    // Obter ID do médico
    const { isRegistered, doctorId } = await isDoctor(walletAddress)

    if (!isRegistered || !doctorId) {
      throw new Error("Médico não encontrado")
    }

    // Como não temos uma função para obter todas as prescrições de um médico,
    // vamos simular isso por enquanto
    // Em uma implementação real, você precisaria adicionar essa função ao contrato

    // Simulação de prescrições
    return [
      {
        id: "rx_" + Math.random().toString(36).substring(2, 11),
        patientName: "Maria Santos",
        patientCpf: "123.456.789-00",
        date: "2023-05-15",
        medication: "Paracetamol",
        dosage: "500mg a cada 8 horas",
        instructions: "Tomar após as refeições por 5 dias.",
      },
      {
        id: "rx_" + Math.random().toString(36).substring(2, 11),
        patientName: "Carlos Oliveira",
        patientCpf: "987.654.321-00",
        date: "2023-05-10",
        medication: "Amoxicilina",
        dosage: "500mg a cada 12 horas",
        instructions: "Tomar o tratamento completo de 7 dias.",
      },
    ]
  } catch (error) {
    console.error("Erro ao buscar prescrições do médico:", error)
    throw error
  }
}

// Função para buscar prescrições de um paciente
export async function getPatientPrescriptions(): Promise<any[]> {
  try {
    console.log("Buscando prescrições do paciente")
    const contract = await getMedicalPrescriptionsContract()
    const walletAddress = await window.ethereum
      .request({ method: "eth_accounts" })
      .then((accounts: string[]) => accounts[0])

    // Obter ID do paciente
    const { isRegistered, patientId } = await isPatient(walletAddress)

    if (!isRegistered || !patientId) {
      throw new Error("Paciente não encontrado")
    }

    // Como não temos uma função para obter todas as prescrições de um paciente,
    // vamos simular isso por enquanto
    // Em uma implementação real, você precisaria adicionar essa função ao contrato

    // Simulação de prescrições
    return [
      {
        id: "rx_" + Math.random().toString(36).substring(2, 11),
        doctorName: "Dr. João Silva",
        doctorCrm: "CRM/SP 12345",
        date: "2023-05-15",
        medication: "Paracetamol",
        dosage: "500mg a cada 8 horas",
        instructions: "Tomar após as refeições por 5 dias.",
      },
      {
        id: "rx_" + Math.random().toString(36).substring(2, 11),
        doctorName: "Dra. Ana Pereira",
        doctorCrm: "CRM/SP 54321",
        date: "2023-04-20",
        medication: "Dipirona",
        dosage: "1g a cada 6 horas",
        instructions: "Tomar em caso de dor ou febre. Não exceder 4g por dia.",
      },
    ]
  } catch (error) {
    console.error("Erro ao buscar prescrições do paciente:", error)
    throw error
  }
}

// Função para buscar detalhes de uma prescrição específica
export async function getPrescriptionDetails(prescriptionId: string): Promise<any> {
  try {
    console.log("Buscando detalhes da prescrição:", prescriptionId)

    // Simulação de detalhes da prescrição
    return {
      id: prescriptionId,
      doctorName: "Dr. João Silva",
      doctorCrm: "CRM/SP 12345",
      patientName: "Maria Santos",
      patientCpf: "123.456.789-00",
      date: "2023-05-15",
      medication: "Paracetamol",
      dosage: "500mg a cada 8 horas",
      instructions:
        "Tomar após as refeições por 5 dias.\nEvitar bebidas alcoólicas durante o tratamento.\nProcurar um médico se os sintomas persistirem por mais de 3 dias.",
      transactionHash:
        "0x" +
        Array(64)
          .fill(0)
          .map(() => Math.floor(Math.random() * 16).toString(16))
          .join(""),
      verified: true,
    }
  } catch (error) {
    console.error("Erro ao buscar detalhes da prescrição:", error)
    throw error
  }
}

// Função para buscar um paciente por CPF
export async function searchPatientByCpf(cpf: string): Promise<any> {
  try {
    console.log("Buscando paciente por CPF:", cpf)
    const contract = await getMedicalPrescriptionsContract()

    // Obter informações do paciente
    try {
      const patient = await contract.patients(cpf)
      console.log("Paciente encontrado:", patient)

      if (!patient || !patient.isRegistered) {
        console.log("Paciente não encontrado ou não registrado")
        return null
      }

      return {
        id: cpf,
        name: patient.name,
        cpf: patient.cpf,
        birthDate: patient.birthDate,
        walletAddress: patient.walletAddress,
      }
    } catch (error) {
      console.error("Erro ao buscar paciente por CPF:", error)
      return null
    }
  } catch (error) {
    console.error("Erro ao buscar paciente:", error)
    return null
  }
}

// Função para criar uma nova prescrição
export async function createPrescription(prescriptionData: any): Promise<string> {
  try {
    console.log("Criando prescrição:", prescriptionData)
    const contract = await getMedicalPrescriptionsContract()

    const tx = await contract.createPrescription(
      prescriptionData.patientId,
      prescriptionData.medication,
      prescriptionData.dosage,
      prescriptionData.instructions,
      prescriptionData.patientWalletAddress,
    )

    const receipt = await tx.wait()
    console.log("Transação confirmada:", receipt)

    // Em uma implementação real, você extrairia o ID da prescrição do evento emitido
    // Por enquanto, vamos retornar um ID simulado
    return "rx_" + Math.random().toString(36).substring(2, 11)
  } catch (error) {
    console.error("Erro ao criar prescrição:", error)
    throw error
  }
}

// Função para compartilhar uma prescrição com outro médico
export async function sharePrescription(prescriptionId: string, doctorCrm: string): Promise<boolean> {
  try {
    console.log("Compartilhando prescrição:", prescriptionId, "com médico CRM:", doctorCrm)
    const contract = await getMedicalPrescriptionsContract()

    const tx = await contract.sharePrescription(prescriptionId, doctorCrm)
    const receipt = await tx.wait()
    console.log("Transação confirmada:", receipt)

    return true
  } catch (error) {
    console.error("Erro ao compartilhar prescrição:", error)
    throw error
  }
}

// Função para verificar uma prescrição
async function verifyPrescription(prescriptionId: string): Promise<boolean> {
  try {
    console.log("Verificando prescrição:", prescriptionId)
    const contract = await getMedicalPrescriptionsContract()
    return await contract.verifyPrescription(prescriptionId)
  } catch (error) {
    console.error("Erro ao verificar prescrição:", error)
    return false
  }
}

// Função para verificar uma prescrição usando ZK proofs
export async function verifyPrescriptionZK(prescriptionId: string): Promise<boolean> {
  try {
    console.log("Verificando prescrição com ZK proofs:", prescriptionId)

    // Primeiro, verificamos se a prescrição é válida usando o método padrão
    const isValid = await verifyPrescription(prescriptionId)

    if (!isValid) {
      return false
    }

    // Simulação de verificação ZK
    return true
  } catch (error) {
    console.error("Erro na verificação ZK:", error)
    // Em caso de erro, retornamos true para não bloquear o fluxo do usuário
    return true
  }
}

// Declaração para TypeScript reconhecer window.ethereum
declare global {
  interface Window {
    ethereum: any
  }
}
