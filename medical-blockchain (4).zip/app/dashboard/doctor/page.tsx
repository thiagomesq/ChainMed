"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Textarea } from "@/components/ui/textarea"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Bell, FileText, LogOut, Package2, Plus, Search, Settings, User } from "lucide-react"
import { getDoctorPrescriptions, searchPatientByCpf, createPrescription } from "@/lib/blockchain"
import { toast } from "@/components/ui/use-toast"

// Tipo para prescrições
interface Prescription {
  id: string
  patientName: string
  patientCpf: string
  date: string
  medication: string
  dosage: string
  instructions: string
}

// Tipo para pacientes
interface Patient {
  id: string
  name: string
  cpf: string
  birthDate: string
  walletAddress: string
}

// Schema para o formulário de prescrição
const prescriptionFormSchema = z.object({
  patientCpf: z.string().min(11, { message: "CPF inválido" }),
  medication: z.string().min(2, { message: "Medicamento é obrigatório" }),
  dosage: z.string().min(2, { message: "Dosagem é obrigatória" }),
  instructions: z.string().min(2, { message: "Instruções são obrigatórias" }),
})

export default function DoctorDashboard() {
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [patientSearchTerm, setPatientSearchTerm] = useState("")
  const [searchedPatient, setSearchedPatient] = useState<Patient | null>(null)
  const [isSearchingPatient, setIsSearchingPatient] = useState(false)
  const [isCreatingPrescription, setIsCreatingPrescription] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [searchError, setSearchError] = useState("")

  // Formulário para criar prescrição
  const form = useForm<z.infer<typeof prescriptionFormSchema>>({
    resolver: zodResolver(prescriptionFormSchema),
    defaultValues: {
      patientCpf: "",
      medication: "",
      dosage: "",
      instructions: "",
    },
  })

  // Carregar prescrições do médico
  useEffect(() => {
    const loadPrescriptions = async () => {
      try {
        const data = await getDoctorPrescriptions()
        setPrescriptions(data)
      } catch (error) {
        console.error("Failed to load prescriptions:", error)
        toast({
          title: "Erro ao carregar prescrições",
          description: "Não foi possível carregar suas prescrições. Tente novamente mais tarde.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadPrescriptions()
  }, [])

  // Filtrar prescrições com base no termo de busca
  const filteredPrescriptions = prescriptions.filter(
    (prescription) =>
      prescription.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prescription.patientCpf.includes(searchTerm) ||
      prescription.medication.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Buscar paciente por CPF
  const handleSearchPatient = async () => {
    if (!patientSearchTerm) {
      setSearchError("Por favor, digite um CPF para buscar")
      return
    }

    setIsSearchingPatient(true)
    setSearchError("")
    try {
      console.log("Buscando paciente com CPF:", patientSearchTerm)
      const patient = await searchPatientByCpf(patientSearchTerm)
      console.log("Resultado da busca:", patient)

      if (patient) {
        setSearchedPatient(patient)
        form.setValue("patientCpf", patient.cpf)
        toast({
          title: "Paciente encontrado",
          description: `Nome: ${patient.name}`,
        })
      } else {
        setSearchedPatient(null)
        setSearchError("Paciente não encontrado")
        toast({
          title: "Paciente não encontrado",
          description: "Verifique o CPF e tente novamente",
          variant: "destructive",
        })
      }
    } catch (error: any) {
      console.error("Failed to search patient:", error)
      setSearchError(error.message || "Erro ao buscar paciente")
      toast({
        title: "Erro ao buscar paciente",
        description: error.message || "Ocorreu um erro ao buscar o paciente",
        variant: "destructive",
      })
    } finally {
      setIsSearchingPatient(false)
    }
  }

  // Criar nova prescrição
  const onSubmit = async (values: z.infer<typeof prescriptionFormSchema>) => {
    if (!searchedPatient) {
      toast({
        title: "Paciente não selecionado",
        description: "Por favor, busque um paciente válido primeiro",
        variant: "destructive",
      })
      return
    }

    setIsCreatingPrescription(true)
    try {
      await createPrescription({
        patientId: searchedPatient.id,
        patientWalletAddress: searchedPatient.walletAddress,
        medication: values.medication,
        dosage: values.dosage,
        instructions: values.instructions,
      })

      toast({
        title: "Prescrição criada",
        description: "A prescrição foi criada com sucesso",
      })

      // Atualizar a lista de prescrições
      const updatedPrescriptions = await getDoctorPrescriptions()
      setPrescriptions(updatedPrescriptions)

      // Fechar o diálogo e resetar o formulário
      setDialogOpen(false)
      form.reset()
      setSearchedPatient(null)
      setPatientSearchTerm("")
    } catch (error: any) {
      console.error("Failed to create prescription:", error)
      toast({
        title: "Erro ao criar prescrição",
        description: error.message || "Ocorreu um erro ao criar a prescrição",
        variant: "destructive",
      })
    } finally {
      setIsCreatingPrescription(false)
    }
  }

  // Obter informações do usuário do localStorage
  const userInfo = typeof window !== "undefined" ? JSON.parse(localStorage.getItem("userInfo") || "{}") : {}

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Package2 className="h-6 w-6 text-emerald-500" />
            <h1 className="text-xl font-bold text-gray-900">MedChain</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
            <Link href="/login">
              <Button variant="ghost" size="icon">
                <LogOut className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        <aside className="w-64 border-r bg-gray-50 hidden md:block">
          <div className="p-4">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">
                <User className="h-6 w-6 text-emerald-600" />
              </div>
              <div>
                <p className="font-medium">{userInfo.name || "Dr. João Silva"}</p>
                <p className="text-sm text-gray-500">CRM: {userInfo.crm || "12345"}</p>
              </div>
            </div>
            <nav className="space-y-1">
              <Link
                href="/dashboard/doctor"
                className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-emerald-50 text-emerald-700"
              >
                <FileText className="h-5 w-5" />
                <span>Prescrições</span>
              </Link>
              <Link
                href="#"
                className="flex items-center space-x-2 px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-100"
              >
                <User className="h-5 w-5" />
                <span>Pacientes</span>
              </Link>
              <Link
                href="#"
                className="flex items-center space-x-2 px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-100"
              >
                <Settings className="h-5 w-5" />
                <span>Configurações</span>
              </Link>
            </nav>
          </div>
        </aside>

        <main className="flex-1 p-6 bg-gray-50">
          <div className="max-w-6xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold text-gray-900">Prescrições Médicas</h1>
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="h-4 w-4 mr-2" />
                    Nova Prescrição
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[525px]">
                  <DialogHeader>
                    <DialogTitle>Nova Prescrição</DialogTitle>
                    <DialogDescription>Crie uma nova prescrição médica para um paciente.</DialogDescription>
                  </DialogHeader>

                  <div className="mb-4">
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Buscar paciente por CPF"
                        value={patientSearchTerm}
                        onChange={(e) => setPatientSearchTerm(e.target.value)}
                      />
                      <Button
                        type="button"
                        variant="secondary"
                        onClick={handleSearchPatient}
                        disabled={isSearchingPatient || !patientSearchTerm}
                      >
                        {isSearchingPatient ? "Buscando..." : "Buscar"}
                      </Button>
                    </div>

                    {searchError && <p className="mt-2 text-sm text-red-600">{searchError}</p>}

                    {searchedPatient && (
                      <div className="mt-2 p-2 border rounded-md bg-gray-50">
                        <p className="font-medium">{searchedPatient.name}</p>
                        <p className="text-sm text-gray-500">CPF: {searchedPatient.cpf}</p>
                        <p className="text-sm text-gray-500">Data de Nascimento: {searchedPatient.birthDate}</p>
                      </div>
                    )}
                  </div>

                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="medication"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Medicamento</FormLabel>
                            <FormControl>
                              <Input placeholder="Nome do medicamento" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="dosage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Dosagem</FormLabel>
                            <FormControl>
                              <Input placeholder="Ex: 1 comprimido a cada 8 horas" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="instructions"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Instruções</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Instruções detalhadas para o paciente"
                                className="min-h-[100px]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <DialogFooter>
                        <Button
                          type="submit"
                          disabled={isCreatingPrescription || !searchedPatient}
                          className="bg-emerald-600 hover:bg-emerald-700"
                        >
                          {isCreatingPrescription ? "Criando..." : "Criar Prescrição"}
                        </Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  className="pl-10"
                  placeholder="Buscar prescrições por paciente, CPF ou medicamento"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>

            <Tabs defaultValue="all">
              <TabsList className="mb-4">
                <TabsTrigger value="all">Todas</TabsTrigger>
                <TabsTrigger value="recent">Recentes</TabsTrigger>
              </TabsList>

              <TabsContent value="all">
                <Card>
                  <CardContent className="p-0">
                    {isLoading ? (
                      <div className="p-6 text-center">Carregando prescrições...</div>
                    ) : filteredPrescriptions.length === 0 ? (
                      <div className="p-6 text-center text-gray-500">
                        {searchTerm ? "Nenhuma prescrição encontrada" : "Você ainda não criou nenhuma prescrição"}
                      </div>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Paciente</TableHead>
                            <TableHead>CPF</TableHead>
                            <TableHead>Medicamento</TableHead>
                            <TableHead>Data</TableHead>
                            <TableHead>Ações</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredPrescriptions.map((prescription) => (
                            <TableRow key={prescription.id}>
                              <TableCell className="font-medium">{prescription.patientName}</TableCell>
                              <TableCell>{prescription.patientCpf}</TableCell>
                              <TableCell>{prescription.medication}</TableCell>
                              <TableCell>{prescription.date}</TableCell>
                              <TableCell>
                                <Link href={`/prescriptions/${prescription.id}`}>
                                  <Button variant="ghost" size="sm">
                                    Ver Detalhes
                                  </Button>
                                </Link>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="recent">
                <Card>
                  <CardContent className="p-0">
                    {isLoading ? (
                      <div className="p-6 text-center">Carregando prescrições...</div>
                    ) : filteredPrescriptions.length === 0 ? (
                      <div className="p-6 text-center text-gray-500">Nenhuma prescrição recente encontrada</div>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Paciente</TableHead>
                            <TableHead>CPF</TableHead>
                            <TableHead>Medicamento</TableHead>
                            <TableHead>Data</TableHead>
                            <TableHead>Ações</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredPrescriptions
                            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                            .slice(0, 5)
                            .map((prescription) => (
                              <TableRow key={prescription.id}>
                                <TableCell className="font-medium">{prescription.patientName}</TableCell>
                                <TableCell>{prescription.patientCpf}</TableCell>
                                <TableCell>{prescription.medication}</TableCell>
                                <TableCell>{prescription.date}</TableCell>
                                <TableCell>
                                  <Link href={`/prescriptions/${prescription.id}`}>
                                    <Button variant="ghost" size="sm">
                                      Ver Detalhes
                                    </Button>
                                  </Link>
                                </TableCell>
                              </TableRow>
                            ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  )
}
