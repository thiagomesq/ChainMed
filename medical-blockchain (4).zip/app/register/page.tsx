"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { connectWallet, registerUser } from "@/lib/blockchain"
import { Loader2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

const doctorFormSchema = z.object({
  name: z.string().min(2, { message: "Nome deve ter pelo menos 2 caracteres" }),
  email: z.string().email({ message: "Email inválido" }),
  crm: z.string().min(5, { message: "CRM inválido" }),
  specialty: z.string().min(2, { message: "Especialidade é obrigatória" }),
  password: z.string().min(6, { message: "Senha deve ter pelo menos 6 caracteres" }),
  role: z.enum(["doctor", "patient"]),
})

const patientFormSchema = z.object({
  name: z.string().min(2, { message: "Nome deve ter pelo menos 2 caracteres" }),
  email: z.string().email({ message: "Email inválido" }),
  cpf: z.string().min(11, { message: "CPF inválido" }).max(14),
  birthDate: z.string(),
  password: z.string().min(6, { message: "Senha deve ter pelo menos 6 caracteres" }),
  role: z.enum(["doctor", "patient"]),
})

export default function RegisterPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [role, setRole] = useState(searchParams.get("role") || "patient")
  const [isConnecting, setIsConnecting] = useState(false)
  const [walletConnected, setWalletConnected] = useState(false)
  const [walletAddress, setWalletAddress] = useState("")
  const [isRegistering, setIsRegistering] = useState(false)
  const [registerError, setRegisterError] = useState("")

  const formSchema = role === "doctor" ? doctorFormSchema : patientFormSchema

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      role: role as "doctor" | "patient",
    },
  })

  useEffect(() => {
    form.setValue("role", role as "doctor" | "patient")
  }, [role, form])

  const handleConnectWallet = async () => {
    setIsConnecting(true)
    setRegisterError("")
    try {
      const address = await connectWallet()
      setWalletAddress(address)
      setWalletConnected(true)
      toast({
        title: "Carteira conectada",
        description: `Endereço: ${address.substring(0, 6)}...${address.substring(address.length - 4)}`,
      })
    } catch (error: any) {
      console.error("Failed to connect wallet:", error)
      setRegisterError(`Erro ao conectar carteira: ${error.message || "Verifique se o MetaMask está instalado"}`)
      toast({
        title: "Erro ao conectar carteira",
        description: error.message || "Certifique-se de que você tem o MetaMask instalado.",
        variant: "destructive",
      })
    } finally {
      setIsConnecting(false)
    }
  }

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    if (!walletConnected) {
      setRegisterError("Por favor, conecte sua carteira antes de se registrar.")
      toast({
        title: "Carteira não conectada",
        description: "Por favor, conecte sua carteira antes de se registrar.",
        variant: "destructive",
      })
      return
    }

    setIsRegistering(true)
    setRegisterError("")
    try {
      // Registrar o usuário na blockchain
      await registerUser(values, walletAddress)

      toast({
        title: "Registro concluído",
        description: "Seu registro foi concluído com sucesso!",
      })

      // Armazenar informações do usuário no localStorage (opcional)
      localStorage.setItem(
        "userInfo",
        JSON.stringify({
          ...values,
          walletAddress,
        }),
      )

      // Redirecionar para a página de dashboard após o registro bem-sucedido
      router.push(`/dashboard/${role}`)
    } catch (error: any) {
      console.error("Registration failed:", error)
      setRegisterError(error.message || "Ocorreu um erro durante o registro. Por favor, tente novamente.")
      toast({
        title: "Falha no registro",
        description: error.message || "Ocorreu um erro durante o registro. Por favor, tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsRegistering(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">Cadastro</h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Já tem uma conta?{" "}
          <Link href="/login" className="font-medium text-emerald-600 hover:text-emerald-500">
            Entrar
          </Link>
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <Card>
          <CardHeader>
            <CardTitle>Cadastro de {role === "doctor" ? "Médico" : "Paciente"}</CardTitle>
            <CardDescription>Preencha os dados abaixo para criar sua conta</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex space-x-4 mb-6">
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="patient"
                  name="role"
                  value="patient"
                  checked={role === "patient"}
                  onChange={() => setRole("patient")}
                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="patient" className="text-sm font-medium text-gray-700">
                  Paciente
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="doctor"
                  name="role"
                  value="doctor"
                  checked={role === "doctor"}
                  onChange={() => setRole("doctor")}
                  className="h-4 w-4 border-gray-300 text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="doctor" className="text-sm font-medium text-gray-700">
                  Médico
                </label>
              </div>
            </div>

            <div className="mb-6">
              <Button
                onClick={handleConnectWallet}
                variant="outline"
                className="w-full"
                disabled={isConnecting || walletConnected}
              >
                {isConnecting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Conectando...
                  </>
                ) : walletConnected ? (
                  <>
                    Carteira Conectada: {walletAddress.substring(0, 6)}...
                    {walletAddress.substring(walletAddress.length - 4)}
                  </>
                ) : (
                  <>Conectar Carteira (MetaMask)</>
                )}
              </Button>
            </div>

            {registerError && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-600 rounded-md text-sm">
                {registerError}
              </div>
            )}

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome Completo</FormLabel>
                      <FormControl>
                        <Input placeholder="Digite seu nome completo" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="seu@email.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {role === "doctor" ? (
                  <>
                    <FormField
                      control={form.control}
                      name="crm"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>CRM</FormLabel>
                          <FormControl>
                            <Input placeholder="Digite seu CRM" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="specialty"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Especialidade</FormLabel>
                          <FormControl>
                            <Input placeholder="Digite sua especialidade" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </>
                ) : (
                  <>
                    <FormField
                      control={form.control}
                      name="cpf"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>CPF</FormLabel>
                          <FormControl>
                            <Input placeholder="Digite seu CPF" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="birthDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Data de Nascimento</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </>
                )}

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Senha</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="******" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full" disabled={isRegistering || !walletConnected}>
                  {isRegistering ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Registrando...
                    </>
                  ) : (
                    "Cadastrar"
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-xs text-gray-500">
              Ao se cadastrar, você concorda com nossos{" "}
              <Link href="/terms" className="text-emerald-600 hover:underline">
                Termos de Serviço
              </Link>{" "}
              e{" "}
              <Link href="/privacy" className="text-emerald-600 hover:underline">
                Política de Privacidade
              </Link>
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
